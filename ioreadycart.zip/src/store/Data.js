export const category = [
  { id: 1, name: "Clothes" },
  { id: 4, name: "shoes" },
  { id: 2, name: "Electronics" },
];
